from __future__ import annotations

import asyncio
import json
import re
from collections.abc import Mapping
from typing import Any

from src.applications.ports.llm import TranslationLLM
from src.applications.services.metadata_normalizer import MetadataNormalizer
from src.applications.services.prompts import METADATA_SYSTEM, REPAIR_SYSTEM, TRANSLATOR_SYSTEM
from src.applications.services.token_budget import estimate_tokens, trim_text_to_tokens
from src.domains.exceptions import ContextWindowError, TranslationError
from src.domains.models import ChapterMetadata, ContextPacket, RawChapter
from src.infrastructures.config.settings import AppSettings


class OpenAITranslationService(TranslationLLM):
    """OpenAI-compatible adapter. No tool loop: two focused calls per normal chapter."""

    def __init__(self, settings: AppSettings):
        try:
            from openai import AsyncOpenAI
        except ImportError as exc:
            raise RuntimeError("The 'openai' package is required. Run: pip install -r requirements.txt") from exc

        self.settings = settings
        self.model_name = settings.model
        self._client = AsyncOpenAI(
            base_url=settings.base_url,
            api_key=settings.api_key,
            timeout=settings.timeout_seconds,
            max_retries=0,
        )
        self._normalizer = MetadataNormalizer()

    async def translate(
        self,
        chapter: RawChapter,
        context: ContextPacket,
        *,
        target_language: str,
    ) -> str:
        user = (
            f"TARGET LANGUAGE: {target_language}\n"
            f"NOVEL: {chapter.novel_id}\n"
            f"CHAPTER: {chapter.chapter_number}\n\n"
            f"CONTINUITY CONTEXT (constraints, not source text):\n{context.text}\n\n"
            f"CURRENT SOURCE CHAPTER:\n{chapter.source_text}"
        )
        self._ensure_fits(TRANSLATOR_SYSTEM, user, self.settings.max_tokens, "translation")
        text = await self._complete(
            system=TRANSLATOR_SYSTEM,
            user=user,
            temperature=self.settings.translation_temperature,
            max_tokens=self.settings.max_tokens,
            json_mode=False,
        )
        if not text.strip():
            raise TranslationError(f"LLM returned an empty translation for chapter {chapter.chapter_number}")
        return text.strip()

    async def extract_metadata(
        self,
        chapter: RawChapter,
        translated_text: str,
        context: ContextPacket,
        *,
        target_language: str,
    ) -> ChapterMetadata:
        metadata_max_tokens = min(self.settings.max_tokens, 6000)
        context_text = context.text
        fixed = (
            f"TARGET LANGUAGE: {target_language}\n"
            f"NOVEL: {chapter.novel_id}\n"
            f"CHAPTER: {chapter.chapter_number}\n\n"
            f"SOURCE CHAPTER:\n{chapter.source_text}\n\n"
            f"FINAL TRANSLATION:\n{translated_text}\n\n"
            "PRIOR CONTINUITY CONTEXT:\n"
        )
        budget = self._safe_input_budget(metadata_max_tokens) - estimate_tokens(METADATA_SYSTEM) - estimate_tokens(fixed)
        if budget < 0:
            raise ContextWindowError(
                f"Chapter {chapter.chapter_number} source + translation do not fit the metadata pass. "
                "Increase CONTEXT_WINDOW or reduce MAX_TOKENS."
            )
        if estimate_tokens(context_text) > budget:
            context_text = trim_text_to_tokens(context_text, max(0, budget))
        user = fixed + context_text
        self._ensure_fits(METADATA_SYSTEM, user, metadata_max_tokens, "metadata extraction")
        raw = await self._complete(
            system=METADATA_SYSTEM,
            user=user,
            temperature=self.settings.metadata_temperature,
            max_tokens=metadata_max_tokens,
            json_mode=True,
        )
        payload = self._parse_json_object(raw)
        return self._normalizer.normalize(payload, chapter_number=chapter.chapter_number, context=context)

    async def repair_translation(
        self,
        chapter: RawChapter,
        translated_text: str,
        context: ContextPacket,
        issues: list[str],
        *,
        target_language: str,
    ) -> str:
        issue_text = "\n".join(f"- {issue}" for issue in issues)
        user = (
            f"TARGET LANGUAGE: {target_language}\n"
            f"NOVEL: {chapter.novel_id}\n"
            f"CHAPTER: {chapter.chapter_number}\n\n"
            f"ISSUES TO REPAIR:\n{issue_text}\n\n"
            f"CONTINUITY CONTEXT:\n{context.text}\n\n"
            f"SOURCE CHAPTER:\n{chapter.source_text}\n\n"
            f"TRANSLATION TO REPAIR:\n{translated_text}"
        )
        self._ensure_fits(REPAIR_SYSTEM, user, self.settings.max_tokens, "repair")
        text = await self._complete(
            system=REPAIR_SYSTEM,
            user=user,
            temperature=self.settings.repair_temperature,
            max_tokens=self.settings.max_tokens,
            json_mode=False,
        )
        if not text.strip():
            raise TranslationError(f"LLM returned an empty repaired translation for chapter {chapter.chapter_number}")
        return text.strip()

    def _safe_input_budget(self, output_tokens: int) -> int:
        return (
            int(self.settings.context_window * self.settings.compact_threshold)
            - output_tokens
            - self.settings.safety_margin_tokens
        )

    def _ensure_fits(self, system: str, user: str, output_tokens: int, stage: str) -> None:
        estimated = estimate_tokens(system) + estimate_tokens(user)
        safe = self._safe_input_budget(output_tokens)
        if estimated > safe:
            raise ContextWindowError(
                f"Estimated {stage} input ({estimated:,} tokens) exceeds safe budget ({safe:,}). "
                "Increase CONTEXT_WINDOW/COMPACT_THRESHOLD, lower MAX_TOKENS, or shorten source chapters."
            )

    async def _complete(
        self,
        *,
        system: str,
        user: str,
        temperature: float,
        max_tokens: int,
        json_mode: bool,
    ) -> str:
        last_error: Exception | None = None
        for attempt in range(self.settings.max_retries + 1):
            try:
                kwargs: dict[str, Any] = {
                    "model": self.settings.model,
                    "messages": [
                        {"role": "system", "content": system},
                        {"role": "user", "content": user},
                    ],
                    "temperature": temperature,
                }
                kwargs[self.settings.token_parameter] = max_tokens
                if self.settings.reasoning_effort:
                    kwargs["reasoning_effort"] = self.settings.reasoning_effort
                if json_mode:
                    kwargs["response_format"] = {"type": "json_object"}
                response = await self._create_with_compatibility_fallbacks(kwargs)
                choice = response.choices[0]
                message = choice.message
                if getattr(choice, "finish_reason", None) == "length":
                    raise TranslationError(
                        f"LLM output hit the configured token limit ({max_tokens}). Increase MAX_TOKENS "
                        "and ensure it remains below CONTEXT_WINDOW."
                    )
                refusal = getattr(message, "refusal", None)
                if refusal:
                    raise TranslationError(f"LLM refused the request: {refusal}")
                content = message.content
                if isinstance(content, str):
                    return content
                if content is None:
                    return ""
                return str(content)
            except Exception as exc:  # provider-specific exception classes vary across compatible APIs
                last_error = exc
                if attempt >= self.settings.max_retries or not self._retryable(exc):
                    break
                await asyncio.sleep(self.settings.retry_base_seconds * (2 ** attempt))
        raise TranslationError(f"LLM request failed after retries: {last_error}") from last_error


    async def _create_with_compatibility_fallbacks(self, kwargs: dict[str, Any]):
        """Retry only unsupported-parameter 400s without consuming the transient retry budget."""
        attempted_swapped_token_parameter = False
        while True:
            try:
                return await self._client.chat.completions.create(**kwargs)
            except Exception as exc:
                if not self._looks_like_unsupported_parameter(exc):
                    raise
                text = str(exc).lower()
                removed = False
                for key in ("response_format", "reasoning_effort", "temperature"):
                    if key in kwargs and key.lower() in text:
                        kwargs.pop(key, None)
                        removed = True
                        break
                if removed:
                    continue
                if (
                    not attempted_swapped_token_parameter
                    and "max_tokens" in kwargs
                    and "max_tokens" in text
                ):
                    kwargs["max_completion_tokens"] = kwargs.pop("max_tokens")
                    attempted_swapped_token_parameter = True
                    continue
                raise

    @staticmethod
    def _retryable(exc: Exception) -> bool:
        status = getattr(exc, "status_code", None)
        if status in {408, 409, 429} or (isinstance(status, int) and status >= 500):
            return True
        text = str(exc).lower()
        return any(token in text for token in ("timeout", "timed out", "rate limit", "temporarily", "connection"))

    @staticmethod
    def _looks_like_unsupported_parameter(exc: Exception) -> bool:
        status = getattr(exc, "status_code", None)
        text = str(exc).lower()
        parameter_words = ("response_format", "reasoning_effort", "temperature", "max_tokens", "parameter", "argument")
        problem_words = ("unsupported", "unknown", "invalid", "not support", "not allowed", "unrecognized")
        return (status in (None, 400, 422)) and any(x in text for x in parameter_words) and any(x in text for x in problem_words)

    @staticmethod
    def _parse_json_object(raw: str) -> Mapping[str, Any]:
        text = raw.strip()
        if text.startswith("```"):
            text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
            text = re.sub(r"\s*```$", "", text)
        try:
            parsed = json.loads(text)
        except json.JSONDecodeError:
            start = text.find("{")
            end = text.rfind("}")
            if start < 0 or end <= start:
                raise TranslationError(f"Metadata response is not valid JSON: {text[:500]}")
            try:
                parsed = json.loads(text[start:end + 1])
            except json.JSONDecodeError as exc:
                raise TranslationError(f"Metadata response is not valid JSON: {text[:500]}") from exc
        if not isinstance(parsed, Mapping):
            raise TranslationError("Metadata response must be a JSON object")
        return parsed
