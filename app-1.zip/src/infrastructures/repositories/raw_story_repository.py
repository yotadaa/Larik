from __future__ import annotations

import hashlib
import re
from pathlib import Path

from src.applications.ports.source import RawStorySource
from src.domains.exceptions import SourceChapterError
from src.domains.models import RawChapter


_CHAPTER_PATTERNS = (
    re.compile(r"(?:^|[-_\s])chapters?[-_\s]*(\d+)(?:\D|$)", re.IGNORECASE),
    re.compile(r"(?:^|[-_\s])ch[-_\s]*(\d+)(?:\D|$)", re.IGNORECASE),
    re.compile(r"^(\d+)(?:\D|$)"),
)
_TITLE_RE = re.compile(r"^#{1,6}\s+(.+?)\s*$")


class FileSystemRawStorySource(RawStorySource):
    def __init__(self, raw_root: str | Path):
        self.raw_root = Path(raw_root).resolve()

    def discover_series(self) -> list[str]:
        if not self.raw_root.exists():
            return []
        return sorted(path.name for path in self.raw_root.iterdir() if path.is_dir())

    def list_chapter_numbers(self, novel_id: str) -> list[int]:
        return sorted(self._chapter_map(novel_id))

    def read_chapter(self, novel_id: str, chapter_number: int) -> RawChapter:
        chapter_map = self._chapter_map(novel_id)
        path = chapter_map.get(chapter_number)
        if not path:
            raise SourceChapterError(f"Raw chapter {chapter_number} not found for {novel_id!r}.")
        text = path.read_text(encoding="utf-8-sig")
        if not text.strip():
            raise SourceChapterError(f"Raw chapter file is empty: {path}")
        digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
        return RawChapter(
            novel_id=novel_id,
            chapter_number=chapter_number,
            path=path,
            source_text=text,
            source_hash=digest,
            title=self._extract_title(text, chapter_number),
        )

    def _chapter_map(self, novel_id: str) -> dict[int, Path]:
        series_dir = (self.raw_root / novel_id).resolve()
        if self.raw_root not in series_dir.parents:
            raise SourceChapterError("Invalid novel_id path traversal")
        if not series_dir.is_dir():
            raise SourceChapterError(f"Raw novel directory does not exist: {series_dir}")

        found: dict[int, Path] = {}
        duplicates: dict[int, list[Path]] = {}
        for path in sorted(series_dir.rglob("*")):
            if not path.is_file() or path.suffix.lower() not in {".md", ".txt"}:
                continue
            number = self._chapter_number(path.stem)
            if number is None:
                continue
            if number in found:
                duplicates.setdefault(number, [found[number]]).append(path)
            else:
                found[number] = path
        if duplicates:
            details = "; ".join(
                f"chapter {number}: {', '.join(str(p.relative_to(series_dir)) for p in paths)}"
                for number, paths in sorted(duplicates.items())
            )
            raise SourceChapterError(f"Duplicate raw chapter numbers detected ({details})")
        return found

    @staticmethod
    def _chapter_number(stem: str) -> int | None:
        for pattern in _CHAPTER_PATTERNS:
            match = pattern.search(stem)
            if match:
                return int(match.group(1))
        return None

    @staticmethod
    def _extract_title(text: str, chapter_number: int) -> str:
        fallback = f"Chapter {chapter_number}"
        headings: list[str] = []
        for line in text.splitlines()[:80]:
            match = _TITLE_RE.match(line.strip())
            if match:
                headings.append(match.group(1).strip())
        # Prefer a specific chapter heading over a website/document wrapper heading.
        for heading in reversed(headings):
            if re.search(rf"\bchapter\s*{chapter_number}\b", heading, re.IGNORECASE):
                return heading
        return headings[0] if headings else fallback
