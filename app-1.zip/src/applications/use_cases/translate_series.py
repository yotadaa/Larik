from __future__ import annotations

import uuid
from dataclasses import dataclass
from typing import Callable

from src.applications.ports.llm import TranslationLLM
from src.applications.ports.repositories import StoryRepository
from src.applications.ports.source import RawStorySource
from src.applications.services.context_builder import ContextBuilder
from src.applications.services.prompts import PROMPT_VERSION
from src.applications.services.quality import TranslationQualityChecker
from src.domains.exceptions import MetadataValidationError, SourceChapterError
from src.domains.models import TranslationResult


EventSink = Callable[[dict], None]


@dataclass(frozen=True, slots=True)
class TranslationWorkflowSettings:
    review_mode: str = "adaptive"  # off | adaptive | always
    strict_sequential: bool = True


@dataclass(frozen=True, slots=True)
class RunSummary:
    run_id: str
    novel_id: str
    lang_id: str
    processed: tuple[int, ...]
    skipped: tuple[int, ...]


class TranslateSeries:
    def __init__(
        self,
        *,
        source: RawStorySource,
        repository: StoryRepository,
        llm: TranslationLLM,
        context_builder: ContextBuilder,
        quality_checker: TranslationQualityChecker | None = None,
        settings: TranslationWorkflowSettings | None = None,
        emit: EventSink | None = None,
    ):
        self.source = source
        self.repository = repository
        self.llm = llm
        self.context_builder = context_builder
        self.quality_checker = quality_checker or TranslationQualityChecker()
        self.settings = settings or TranslationWorkflowSettings()
        self.emit = emit or (lambda _event: None)

    async def execute(
        self,
        novel_id: str,
        lang_id: str,
        *,
        start: int | None = None,
        end: int | None = None,
        force: bool = False,
        max_chapters: int | None = None,
    ) -> RunSummary:
        available = self.source.list_chapter_numbers(novel_id)
        if not available:
            raise SourceChapterError(f"No raw chapters found for {novel_id!r}.")

        first_available = available[0]
        last_available = available[-1]
        start = first_available if start is None else start
        end = last_available if end is None else end
        if start > end:
            raise SourceChapterError("start chapter must be <= end chapter")
        selected = [n for n in available if start <= n <= end]
        if not selected:
            raise SourceChapterError(f"No raw chapters exist in requested range {start}-{end}.")
        if max_chapters is not None:
            selected = selected[: max(0, max_chapters)]
        if not selected:
            raise SourceChapterError("max_chapters resulted in an empty run")

        if self.settings.strict_sequential and selected[0] > first_available:
            previous = max((n for n in available if n < selected[0]), default=None)
            if previous is not None and not self.repository.has_completed_chapter(novel_id, lang_id, previous):
                raise SourceChapterError(
                    f"Sequential context is incomplete: chapter {previous} has not been translated for "
                    f"{novel_id}/{lang_id}. Process earlier chapters first or disable strict mode explicitly."
                )

        run_id = uuid.uuid4().hex
        self.repository.start_run(run_id, novel_id, lang_id, selected[0], selected[-1])
        processed: list[int] = []
        skipped: list[int] = []

        try:
            for index, chapter_number in enumerate(selected, 1):
                self._emit(run_id, chapter_number, "read", f"Reading raw chapter ({index}/{len(selected)})")
                chapter = self.source.read_chapter(novel_id, chapter_number)

                if not force and self.repository.is_chapter_current(
                    novel_id,
                    lang_id,
                    chapter_number,
                    chapter.source_hash,
                    PROMPT_VERSION,
                    self.llm.model_name,
                ):
                    skipped.append(chapter_number)
                    self._emit(run_id, chapter_number, "skip", "Already current; skipping LLM calls")
                    continue

                self._emit(run_id, chapter_number, "context", "Building bounded continuity context")
                context = self.context_builder.build(chapter, lang_id)
                self._emit(
                    run_id,
                    chapter_number,
                    "context",
                    f"Context ready (~{context.estimated_tokens} tokens; previous={list(context.included_previous_chapters)})",
                )

                self._emit(run_id, chapter_number, "translate", "Translating chapter")
                translated = await self.llm.translate(chapter, context, target_language=lang_id)
                deterministic_issues = self.quality_checker.check(chapter.source_text, translated)

                self._emit(run_id, chapter_number, "metadata", "Extracting compact continuity metadata")
                metadata = await self.llm.extract_metadata(
                    chapter,
                    translated,
                    context,
                    target_language=lang_id,
                )
                if not metadata.summary.strip():
                    raise MetadataValidationError(
                        f"LLM metadata for chapter {chapter_number} did not include a continuity summary."
                    )

                review_issues = list(dict.fromkeys([*deterministic_issues, *metadata.quality_flags]))
                if self._should_repair(review_issues):
                    self._emit(
                        run_id,
                        chapter_number,
                        "repair",
                        "Quality repair triggered: " + "; ".join(review_issues),
                    )
                    translated = await self.llm.repair_translation(
                        chapter,
                        translated,
                        context,
                        review_issues or ["perform a final consistency review"],
                        target_language=lang_id,
                    )
                    post_issues = self.quality_checker.check(chapter.source_text, translated)
                    if post_issues:
                        self._emit(
                            run_id,
                            chapter_number,
                            "repair",
                            "Repair completed with remaining heuristic warnings: " + "; ".join(post_issues),
                        )
                    # Metadata must describe the final text, not the pre-repair draft.
                    metadata = await self.llm.extract_metadata(
                        chapter,
                        translated,
                        context,
                        target_language=lang_id,
                    )
                    if not metadata.summary.strip():
                        raise MetadataValidationError(
                            f"LLM metadata after repair for chapter {chapter_number} has no summary."
                        )

                result = TranslationResult(
                    raw_chapter=chapter,
                    translated_text=translated.strip(),
                    metadata=metadata,
                    context_fingerprint=context.context_fingerprint,
                    model=self.llm.model_name,
                    prompt_version=PROMPT_VERSION,
                )
                self._emit(run_id, chapter_number, "commit", "Writing chapter + metadata atomically to SQLite")
                self.repository.save_translation(result, lang_id)
                processed.append(chapter_number)
                self._emit(run_id, chapter_number, "done", "Chapter completed")

            self.repository.finish_run(run_id, "completed")
            return RunSummary(run_id, novel_id, lang_id, tuple(processed), tuple(skipped))
        except Exception as exc:
            self.repository.finish_run(run_id, "failed", str(exc))
            raise

    def _should_repair(self, issues: list[str]) -> bool:
        mode = self.settings.review_mode.strip().lower()
        if mode == "always":
            return True
        if mode == "off":
            return False
        return bool(issues)

    def _emit(self, run_id: str, chapter: int, stage: str, message: str) -> None:
        self.emit({"run_id": run_id, "chapter": chapter, "stage": stage, "message": message})
