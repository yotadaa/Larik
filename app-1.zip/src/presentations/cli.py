from __future__ import annotations

import argparse
import asyncio
import json
import sys
from pathlib import Path

from src.applications.services.context_builder import ContextBuilder
from src.applications.services.quality import TranslationQualityChecker
from src.applications.use_cases.translate_series import TranslateSeries, TranslationWorkflowSettings
from src.domains.exceptions import TranslationError
from src.infrastructures.config.settings import AppSettings
from src.infrastructures.database.repository import SQLiteStoryRepository
from src.infrastructures.llm.openai_service import OpenAITranslationService
from src.infrastructures.repositories.raw_story_repository import FileSystemRawStorySource


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="larik",
        description="Sequential multi-series novel translator with compact temporal metadata.",
    )
    parser.add_argument("--root", type=Path, default=Path.cwd(), help="Project root (default: current directory)")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("init-db", help="Create/upgrade the SQLite schema")
    sub.add_parser("list", help="List novel series under story/raw")

    status = sub.add_parser("status", help="Show translated chapter and metadata counts")
    status.add_argument("novel_id")
    status.add_argument("--lang", default="id")

    translate = sub.add_parser("translate", help="Translate a sequential chapter range")
    translate.add_argument("novel_id")
    translate.add_argument("--lang", default="id", help="Target language id (default: id)")
    translate.add_argument("--start", type=int)
    translate.add_argument("--end", type=int)
    translate.add_argument("--max-chapters", type=int, help="Safety cap for this invocation")
    translate.add_argument("--force", action="store_true", help="Retranslate even when source/model/prompt are current")
    translate.add_argument("--allow-context-gap", action="store_true", help="Allow starting after an untranslated previous chapter")
    translate.add_argument("--quiet", action="store_true")
    return parser


def _event_printer(event: dict) -> None:
    chapter = event.get("chapter")
    stage = event.get("stage", "pipeline")
    message = event.get("message", "")
    print(f"[ch {chapter:04d}] {stage:>9} | {message}", file=sys.stderr, flush=True)


async def _run_translate(args: argparse.Namespace, settings: AppSettings) -> int:
    source = FileSystemRawStorySource(settings.raw_story_root)
    repo = SQLiteStoryRepository(settings.database_path)
    repo.initialize()
    try:
        llm = OpenAITranslationService(settings)
        context_builder = ContextBuilder(repo, settings.context_settings())
        workflow_settings = TranslationWorkflowSettings(
            review_mode=settings.review_mode,
            strict_sequential=False if args.allow_context_gap else settings.strict_sequential,
        )
        use_case = TranslateSeries(
            source=source,
            repository=repo,
            llm=llm,
            context_builder=context_builder,
            quality_checker=TranslationQualityChecker(),
            settings=workflow_settings,
            emit=(lambda _event: None) if args.quiet else _event_printer,
        )
        summary = await use_case.execute(
            args.novel_id,
            args.lang,
            start=args.start,
            end=args.end,
            force=args.force,
            max_chapters=args.max_chapters,
        )
        print(json.dumps({
            "run_id": summary.run_id,
            "novel_id": summary.novel_id,
            "lang_id": summary.lang_id,
            "processed": list(summary.processed),
            "skipped": list(summary.skipped),
            "database": str(settings.database_path),
        }, ensure_ascii=False, indent=2))
        return 0
    finally:
        repo.close()


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    root = args.root.resolve()

    try:
        require_llm = args.command == "translate"
        settings = AppSettings.from_env(root, require_llm=require_llm)

        if args.command == "list":
            source = FileSystemRawStorySource(settings.raw_story_root)
            for slug in source.discover_series():
                count = len(source.list_chapter_numbers(slug))
                print(f"{slug}\t{count} raw chapters")
            return 0

        repo = SQLiteStoryRepository(settings.database_path)
        try:
            repo.initialize()
            if args.command == "init-db":
                print(settings.database_path)
                return 0
            if args.command == "status":
                print(json.dumps({
                    "novel_id": args.novel_id,
                    "lang_id": args.lang,
                    "completed_chapters": repo.chapter_count(args.novel_id, args.lang),
                    "metadata_snapshot_rows": repo.metadata_counts(args.novel_id, args.lang),
                    "database": str(settings.database_path),
                }, ensure_ascii=False, indent=2))
                return 0
        finally:
            repo.close()

        if args.command == "translate":
            return asyncio.run(_run_translate(args, settings))
        parser.error(f"Unsupported command: {args.command}")
        return 2
    except (ValueError, TranslationError, RuntimeError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
